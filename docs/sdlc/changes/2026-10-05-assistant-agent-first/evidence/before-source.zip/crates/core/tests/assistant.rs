use codetwo_core::{
    assistant::*,
    provider::ProviderId,
    session::{RunFailureReason, Session, SessionActivity, SessionRunState},
    Store,
};

fn configured(store: &Store) -> AssistantState {
    store.add_project("/project-a", Some("A"), 0).unwrap();
    store.add_project("/project-b", Some("B"), 0).unwrap();
    let state = store
        .edit_assistant(
            0,
            AssistantEdit::Settings {
                settings: AssistantSettings {
                    enabled: true,
                    projects: vec!["/project-a".into()],
                    provider: ProviderId::Codex,
                    model: None,
                    reasoning_effort: None,
                    concurrency: 1,
                    turn_limit: 5,
                    dispatch_limit: 2,
                },
            },
        )
        .unwrap();
    store
        .edit_assistant(
            state.revision,
            AssistantEdit::Goal {
                id: None,
                project_path: "/project-a".into(),
                title: "Repair login".into(),
                acceptance: "Regression passes; provide the commit".into(),
                priority: 1,
            },
        )
        .unwrap()
}
fn dispatch(state: &AssistantState) -> AssistantDecision {
    AssistantDecision {
        summary: "Repair the regression".into(),
        actions: vec![AssistantAction::Dispatch {
            goal_id: state.goals[0].id.clone(),
            instruction: "Repair login within the project and run the regression".into(),
        }],
    }
}
#[test]
fn durable_goals_reject_stale_decisions_and_preserve_user_takeover() {
    let temp = tempfile::tempdir().unwrap();
    let db = temp.path().join("assistant.db");
    let old = {
        let store = Store::open(db.to_str().unwrap()).unwrap();
        let state = configured(&store);
        store
            .add_memory(
                "/project-a",
                "constraint",
                "Keep the login API stable",
                true,
            )
            .unwrap();
        state
    };
    let store = Store::open(db.to_str().unwrap()).unwrap();
    let state = store.assistant_state().unwrap();
    assert_eq!(state.goals[0].title, old.goals[0].title);
    let paused = store
        .edit_assistant(
            state.revision,
            AssistantEdit::Takeover {
                id: state.goals[0].id.clone(),
            },
        )
        .unwrap();
    let stale = apply_decision(&state, &[], dispatch(&state)).unwrap();
    assert!(store.save_assistant(state.revision, stale).is_err());
    assert!(apply_decision(&paused, &[], dispatch(&paused)).is_err());
    assert_eq!(
        store.list_memories("/project-a", 10).unwrap()[0].content,
        "Keep the login API stable"
    );
}
#[test]
fn scope_concurrency_and_interrupted_receipts_fail_closed() {
    let store = Store::open_in_memory().unwrap();
    let state = configured(&store);
    let dispatched = apply_decision(&state, &[], dispatch(&state)).unwrap();
    assert!(apply_decision(&dispatched, &[], dispatch(&dispatched)).is_err());
    let mut limited = state.clone();
    limited.dispatches = limited.settings.as_ref().unwrap().dispatch_limit;
    assert!(apply_decision(&limited, &[], dispatch(&limited))
        .unwrap_err()
        .to_string()
        .contains("allowance exhausted"));
    let mut outside = Session::new(ProviderId::Codex, "/project-b");
    outside.id = "outside".into();
    assert!(apply_decision(
        &state,
        &[outside],
        AssistantDecision {
            summary: "link".into(),
            actions: vec![AssistantAction::Link {
                goal_id: state.goals[0].id.clone(),
                session_id: "outside".into()
            }]
        }
    )
    .is_err());
    let mut interrupted = Session::new(ProviderId::Codex, "/project-a");
    interrupted.activity = SessionActivity {
        revision: 2,
        state: SessionRunState::Failed {
            turn_id: None,
            reason: RunFailureReason::Interrupted,
            message: "restart".into(),
        },
    };
    let mut unresolved = dispatched;
    unresolved.goals[0].assignments[0].session_id = Some(interrupted.id.clone());
    assert!(apply_decision(&unresolved, &[interrupted], dispatch(&unresolved)).is_err());
}
#[test]
fn idle_is_not_acceptance_and_verdicts_bind_the_current_revision() {
    let store = Store::open_in_memory().unwrap();
    let mut state = configured(&store);
    let temp = tempfile::tempdir().unwrap();
    std::fs::write(temp.path().join("report.txt"), b"report v1").unwrap();
    let mut session = Session::new(ProviderId::Codex, temp.path().to_string_lossy().to_string());
    session.project_path = Some("/project-a".into());
    state = apply_decision(&state, &[], dispatch(&state)).unwrap();
    state.goals[0].assignments[0].session_id = Some(session.id.clone());
    assert_eq!(state.goals[0].status, GoalStatus::Active);
    state.goals[0].next_step = "Wait for the worker".into();
    state.goals[0].blocker = "Pending evidence".into();
    let artifacts = vec![ArtifactStamp {
        path: "report.txt".into(),
        sha256: {
            use sha2::{Digest, Sha256};
            format!("{:x}", Sha256::digest(b"report v1"))
        },
    }];
    store.upsert_session(&session).unwrap();
    store.save_assistant(state.revision, state).unwrap();
    store
        .assistant_worker(
            &session.id,
            WorkerOperation::Confirm {
                contract_revision: 1,
                message_ids: vec![],
            },
        )
        .unwrap();
    store
        .assistant_worker(
            &session.id,
            WorkerOperation::Submit {
                contract_revision: 1,
                evidence: "report checked".into(),
                artifacts,
            },
        )
        .unwrap();
    state = store.assistant_state().unwrap();
    let accept = |revision| AssistantDecision {
        summary: "Checked the result".into(),
        actions: vec![AssistantAction::Accept {
            goal_id: state.goals[0].id.clone(),
            session_id: session.id.clone(),
            activity_revision: revision,
            evidence: "report v1; login regression passed".into(),
            artifacts: vec![ArtifactStamp {
                path: "report.txt".into(),
                sha256: {
                    use sha2::{Digest, Sha256};
                    format!("{:x}", Sha256::digest(b"report v1"))
                },
            }],
        }],
    };
    assert!(apply_decision(&state, &[session.clone()], accept(3)).is_err());
    let done = apply_decision(
        &state,
        &[session.clone()],
        accept(session.activity.revision),
    )
    .unwrap();
    assert_eq!(done.goals[0].status, GoalStatus::Completed);
    assert!(done.goals[0].next_step.is_empty() && done.goals[0].blocker.is_empty());
    std::fs::write(temp.path().join("report.txt"), b"report v2").unwrap();
    assert!(verify_artifacts(
        &session.cwd,
        &done.goals[0].verdict.as_ref().unwrap().artifacts
    )
    .is_err());
    assert!(apply_decision(
        &state,
        &[session.clone()],
        accept(session.activity.revision)
    )
    .is_err());
}
#[test]
fn forgetting_and_global_switch_control_actual_project_recall() {
    let store = Store::open_in_memory().unwrap();
    configured(&store);
    let session = Session::new(ProviderId::Codex, "/project-a");
    store.upsert_session(&session).unwrap();
    let note = store
        .add_memory(
            "/project-a",
            "preference",
            "Prefer a stable login API",
            true,
        )
        .unwrap();
    store
        .add_memory("/project-b", "fact", "PRIVATE_B_ONLY", true)
        .unwrap();
    let before = store
        .memory_context_with_receipt("/project-a", &session.id, "login")
        .unwrap();
    assert!(before.items.iter().any(|m| m.id == note.id));
    assert!(!before.block.contains("PRIVATE_B_ONLY"));
    store.set_memory_active(&note.id, false).unwrap();
    assert!(!store
        .memory_context_with_receipt("/project-a", &session.id, "login")
        .unwrap()
        .items
        .iter()
        .any(|m| m.id == note.id));
    store
        .add_memory(GLOBAL_MEMORY, "preference", "Use short updates", true)
        .unwrap();
    let mut settings = store.memory_settings().unwrap();
    settings.enabled = false;
    store.set_memory_settings(settings).unwrap();
    assert!(store
        .memory_context_with_receipt(GLOBAL_MEMORY, &session.id, "updates")
        .unwrap()
        .block
        .is_empty());
}
#[test]
fn entire_proposal_is_rejected_without_partial_dispatch() {
    let store = Store::open_in_memory().unwrap();
    let state = configured(&store);
    let mut proposal = dispatch(&state);
    proposal.actions.push(AssistantAction::Update {
        goal_id: "unknown".into(),
        next_step: "bad".into(),
        blocker: String::new(),
    });
    assert!(apply_decision(&state, &[], proposal).is_err());
    assert!(store.assistant_state().unwrap().goals[0]
        .assignments
        .is_empty());
    assert!(parse_decision(r#"{"summary":"x","actions":[],"enable_all_projects":true}"#).is_err());
}

#[test]
fn takeover_of_uncreated_intent_releases_slot_and_resume_can_dispatch() {
    let store = Store::open_in_memory().unwrap();
    let state = configured(&store);
    let dispatched = apply_decision(&state, &[], dispatch(&state)).unwrap();
    let saved = store.save_assistant(state.revision, dispatched).unwrap();
    let paused = store
        .edit_assistant(
            saved.revision,
            AssistantEdit::Takeover {
                id: saved.goals[0].id.clone(),
            },
        )
        .unwrap();
    assert_eq!(paused.goals[0].assignments.len(), 1);
    assert!(!paused.goals[0].assignments[0].owned);
    assert!(paused.goals[0].assignments[0].taken_over);
    let resumed = store
        .edit_assistant(
            paused.revision,
            AssistantEdit::Status {
                id: paused.goals[0].id.clone(),
                status: GoalStatus::Active,
            },
        )
        .unwrap();
    assert!(apply_decision(&resumed, &[], dispatch(&resumed)).is_ok());
}

#[cfg(unix)]
#[test]
fn artifact_verification_rejects_fifo_and_workspace_escape() {
    let temp = tempfile::tempdir().unwrap();
    let pipe = temp.path().join("pipe");
    assert!(std::process::Command::new("mkfifo")
        .arg(&pipe)
        .status()
        .unwrap()
        .success());
    let stamp = ArtifactStamp {
        path: "pipe".into(),
        sha256: "0".repeat(64),
    };
    assert!(verify_artifacts(temp.path().to_str().unwrap(), &[stamp])
        .unwrap_err()
        .to_string()
        .contains("regular file"));
    let outside = tempfile::NamedTempFile::new().unwrap();
    std::os::unix::fs::symlink(outside.path(), temp.path().join("outside")).unwrap();
    let stamp = ArtifactStamp {
        path: "outside".into(),
        sha256: "0".repeat(64),
    };
    assert!(verify_artifacts(temp.path().to_str().unwrap(), &[stamp])
        .unwrap_err()
        .to_string()
        .contains("escapes"));
}

fn managed(store: &Store, root: &std::path::Path) -> (AssistantState, Session) {
    let state = configured(store);
    let mut state = apply_decision(&state, &[], dispatch(&state)).unwrap();
    let mut session = Session::new(ProviderId::Codex, root.to_string_lossy().to_string());
    session.project_path = Some("/project-a".into());
    store.upsert_session(&session).unwrap();
    state.goals[0].assignments[0].session_id = Some(session.id.clone());
    state.goals[0].assignments[0].submitted = true;
    store.save_assistant(state.revision, state).unwrap();
    store
        .assistant_worker(
            &session.id,
            WorkerOperation::Confirm {
                contract_revision: 1,
                message_ids: vec![],
            },
        )
        .unwrap();
    (store.assistant_state().unwrap(), session)
}
fn stamps(root: &std::path::Path, bytes: &[u8]) -> Vec<ArtifactStamp> {
    use sha2::{Digest, Sha256};
    std::fs::write(root.join("report.txt"), bytes).unwrap();
    vec![ArtifactStamp {
        path: "report.txt".into(),
        sha256: format!("{:x}", Sha256::digest(bytes)),
    }]
}
#[test]
fn worker_identity_idempotency_questions_and_final_review_are_versioned() {
    let store = Store::open_in_memory().unwrap();
    let root = tempfile::tempdir().unwrap();
    let (state, s) = managed(&store, root.path());
    assert!(store
        .assistant_worker("forged-session", WorkerOperation::Context)
        .is_err());
    let op = WorkerOperation::Progress {
        content: "Checked local input".into(),
    };
    let response = store
        .assistant_worker_command(&s.id, "progress-1", op.clone())
        .unwrap();
    assert_eq!(
        response,
        store
            .assistant_worker_command(&s.id, "progress-1", op)
            .unwrap()
    );
    assert_eq!(store.assistant_state().unwrap().messages.len(), 1);
    assert!(store
        .assistant_worker_command(
            &s.id,
            "progress-1",
            WorkerOperation::Progress {
                content: "different".into()
            }
        )
        .is_err());
    let artifacts = stamps(root.path(), b"version 1");
    store
        .assistant_worker(
            &s.id,
            WorkerOperation::Submit {
                contract_revision: 1,
                evidence: "Content checked".into(),
                artifacts,
            },
        )
        .unwrap();
    let question = store
        .assistant_worker(
            &s.id,
            WorkerOperation::Ask {
                title: "Which locale?".into(),
                context: "Product decision".into(),
                options: vec!["English".into(), "Chinese".into()],
                blocking: true,
                factual: false,
            },
        )
        .unwrap();
    let before = store.assistant_state().unwrap();
    assert!(store
        .edit_assistant(
            before.revision,
            AssistantEdit::Review {
                goal_id: state.goals[0].id.clone(),
                verdict: "accepted".into(),
                evidence: "Independent file check".into()
            }
        )
        .is_err());
    let answered = store
        .edit_assistant(
            before.revision,
            AssistantEdit::Answer {
                question_id: question["question_id"].as_str().unwrap().into(),
                answer: "Chinese".into(),
            },
        )
        .unwrap();
    assert!(answered
        .messages
        .iter()
        .any(|m| m.reply_to.as_deref() == question["question_id"].as_str()));
    // Requirements change while the answer is queued: all old questions/results become stale.
    let changed = store
        .edit_assistant(
            answered.revision,
            AssistantEdit::Goal {
                id: Some(state.goals[0].id.clone()),
                project_path: "/project-a".into(),
                title: "Updated report".into(),
                acceptance: "Version 2".into(),
                priority: 1,
            },
        )
        .unwrap();
    assert_eq!(changed.goals[0].contract_revision, 2);
    assert!(changed.goals[0].assignments[0].stop_requested);
    assert!(changed.goals[0].assignments[0].result.is_none());
    assert!(store
        .assistant_worker(
            &s.id,
            WorkerOperation::Confirm {
                contract_revision: 1,
                message_ids: vec![]
            }
        )
        .is_err());
    assert!(store
        .assistant_worker(
            &s.id,
            WorkerOperation::Submit {
                contract_revision: 1,
                evidence: "stale".into(),
                artifacts: stamps(root.path(), b"stale")
            }
        )
        .is_err());
}
#[test]
fn native_question_retry_clears_the_rejected_attempt_and_permissions_remain_specific() {
    let store = Store::open_in_memory().unwrap();
    let root = tempfile::tempdir().unwrap();
    let (_, s) = managed(&store, root.path());
    store
        .assistant_worker(
            &s.id,
            WorkerOperation::Ask {
                title: "Read a file?".into(),
                context: String::new(),
                options: vec![],
                blocking: true,
                factual: false,
            },
        )
        .unwrap();
    let mut state = store.assistant_state().unwrap();
    let id = state.questions[0].id.clone();
    state.questions[0].source_input=Some(serde_json::from_value(serde_json::json!({"input_id":"input-1","kind":"permission","title":"Read a file?","options":[["allow_once","Allow once"]],"sequence":1})).unwrap());
    state.questions[0].answer_delivery_id = Some("native:rejected".into());
    state = store.save_assistant(state.revision, state).unwrap();
    assert!(store
        .edit_assistant(
            state.revision,
            AssistantEdit::Answer {
                question_id: id.clone(),
                answer: "invented_option".into()
            }
        )
        .is_err());
    let answered = store
        .edit_assistant(
            state.revision,
            AssistantEdit::Answer {
                question_id: id,
                answer: "allow_once".into(),
            },
        )
        .unwrap();
    assert!(answered.questions[0].answer_delivery_id.is_none());
    assert_eq!(answered.questions[0].answered_by.as_deref(), Some("user"));
}
#[test]
fn dependency_files_and_submitted_input_versions_cannot_be_laundered_by_confirmation() {
    let store = Store::open_in_memory().unwrap();
    let a = tempfile::tempdir().unwrap();
    let b = tempfile::tempdir().unwrap();
    let (mut state, sa) = managed(&store, a.path());
    let gid_a = state.goals[0].id.clone();
    let artifacts = stamps(a.path(), b"a1");
    store
        .assistant_worker(
            &sa.id,
            WorkerOperation::Submit {
                contract_revision: 1,
                evidence: "a1 checked".into(),
                artifacts,
            },
        )
        .unwrap();
    state = store.assistant_state().unwrap();
    state = store
        .edit_assistant(
            state.revision,
            AssistantEdit::Review {
                goal_id: gid_a.clone(),
                verdict: "accepted".into(),
                evidence: "Actual a1 content".into(),
            },
        )
        .unwrap();
    state = store
        .edit_assistant(
            state.revision,
            AssistantEdit::Goal {
                id: None,
                project_path: "/project-a".into(),
                title: "Dependent report".into(),
                acceptance: "Uses accepted A".into(),
                priority: 1,
            },
        )
        .unwrap();
    let gid_b = state.goals[1].id.clone();
    state = store
        .edit_assistant(
            state.revision,
            AssistantEdit::Dependencies {
                goal_id: gid_b.clone(),
                dependencies: vec![gid_a.clone()],
            },
        )
        .unwrap();
    state = apply_decision(
        &state,
        &[sa.clone()],
        AssistantDecision {
            summary: "Use the input".into(),
            actions: vec![AssistantAction::Dispatch {
                goal_id: gid_b.clone(),
                instruction: "Read accepted A".into(),
            }],
        },
    )
    .unwrap();
    let mut sb = Session::new(ProviderId::Codex, b.path().to_string_lossy().to_string());
    sb.project_path = Some("/project-a".into());
    store.upsert_session(&sb).unwrap();
    state.goals[1].assignments[0].session_id = Some(sb.id.clone());
    state = store.save_assistant(state.revision, state).unwrap();
    let version = state.goals[1].contract_revision;
    store
        .assistant_worker(
            &sb.id,
            WorkerOperation::Confirm {
                contract_revision: version,
                message_ids: vec![],
            },
        )
        .unwrap();
    store
        .assistant_worker(
            &sb.id,
            WorkerOperation::Submit {
                contract_revision: version,
                evidence: "Uses A1".into(),
                artifacts: stamps(b.path(), b"b from a1"),
            },
        )
        .unwrap();
    // No periodic reconcile occurs between editing A and attempting to accept B.
    std::fs::write(a.path().join("report.txt"), b"a changed externally").unwrap();
    state = store.assistant_state().unwrap();
    assert!(store
        .edit_assistant(
            state.revision,
            AssistantEdit::Review {
                goal_id: gid_b.clone(),
                verdict: "accepted".into(),
                evidence: "B file checked".into()
            }
        )
        .is_err());
    // Simulate a new accepted input version. Merely confirming B must discard its old result.
    state.goals[0].contract_revision += 1;
    state.goals[0].verdict.as_mut().unwrap().artifacts = stamps(a.path(), b"a2");
    state = store.save_assistant(state.revision, state).unwrap();
    assert!(store
        .assistant_worker(
            &sb.id,
            WorkerOperation::Confirm {
                contract_revision: version,
                message_ids: vec![],
            }
        )
        .is_err());
    state.goals[0].verdict.as_mut().unwrap().contract_revision = state.goals[0].contract_revision;
    store.save_assistant(state.revision, state).unwrap();
    store
        .assistant_worker(
            &sb.id,
            WorkerOperation::Confirm {
                contract_revision: version,
                message_ids: vec![],
            },
        )
        .unwrap();
    state = store.assistant_state().unwrap();
    assert!(state.goals[1].assignments[0].result.is_none());
    assert!(store
        .edit_assistant(
            state.revision,
            AssistantEdit::Review {
                goal_id: gid_b,
                verdict: "accepted".into(),
                evidence: "Only confirmed".into()
            }
        )
        .is_err());
}

#[test]
fn a_recorded_native_answer_is_revoked_atomically_before_changed_control_can_deliver_it() {
    for change in ["revision", "stop", "cancel", "takeover", "remove_scope"] {
        let store = Store::open_in_memory().unwrap();
        let root = tempfile::tempdir().unwrap();
        let (mut state, _) = managed(&store, root.path());
        let goal = state.goals[0].clone();
        let assignment = goal.assignments[0].clone();
        let q:CoordinationQuestion=serde_json::from_value(serde_json::json!({"id":"native:q","goal_id":goal.id,"assignment_id":assignment.id,"contract_revision":1,"author":"worker","title":"Allow read?","context":"Concrete operation","options":[],"blocking":true,"state":"answered","answer":"allow_once","answered_by":"user","source_input":{"input_id":"input","kind":"permission","title":"Read","options":[["allow_once","Allow once"]],"sequence":1},"request_id":null,"answer_delivery_id":null})).unwrap();
        assert!(native_answer_valid(&state, &q));
        state.questions.push(q);
        match change {
            "revision" => state.goals[0].contract_revision += 1,
            "stop" => state.goals[0].assignments[0].stop_requested = true,
            "cancel" => state.goals[0].status = GoalStatus::Cancelled,
            "takeover" => state.goals[0].assignments[0].taken_over = true,
            "remove_scope" => state.settings.as_mut().unwrap().projects.clear(),
            _ => unreachable!(),
        }
        let state = store.save_assistant(state.revision, state).unwrap();
        assert!(!native_answer_valid(&state, &state.questions[0]));
        assert_eq!(state.questions[0].state, "expired");
        assert_eq!(
            state.questions[0].answer_delivery_id.as_deref(),
            Some("control:revoked")
        );
    }
}

#[test]
fn unknown_delivery_and_claimed_native_answers_block_submission_and_acceptance() {
    for transport in [
        "recorded",
        "queued",
        "submitting",
        "unknown",
        "accepted",
        "failed",
    ] {
        let store = Store::open_in_memory().unwrap();
        let root = tempfile::tempdir().unwrap();
        let (_state, session) = managed(&store, root.path());
        let artifacts = stamps(root.path(), b"current result");
        store
            .assistant_worker(
                &session.id,
                WorkerOperation::Submit {
                    contract_revision: 1,
                    evidence: "checked".into(),
                    artifacts: artifacts.clone(),
                },
            )
            .unwrap();
        let mut state = store.assistant_state().unwrap();
        let goal = state.goals[0].clone();
        let id = add_message(
            &mut state,
            &goal.id,
            "Required correction".into(),
            "auto",
            "user",
            None,
        )
        .unwrap();
        state
            .messages
            .iter_mut()
            .find(|m| m.id == id)
            .unwrap()
            .state = transport.into();
        let state = store.save_assistant(state.revision, state).unwrap();
        assert!(
            store
                .assistant_worker(
                    &session.id,
                    WorkerOperation::Submit {
                        contract_revision: 1,
                        evidence: "checked".into(),
                        artifacts
                    }
                )
                .is_err(),
            "{transport}"
        );
        assert!(
            store
                .edit_assistant(
                    state.revision,
                    AssistantEdit::Review {
                        goal_id: goal.id,
                        verdict: "accepted".into(),
                        evidence: "checked".into()
                    }
                )
                .is_err(),
            "{transport}"
        );
    }
    for outcome in ["delivery_unknown", "expired", "answered"] {
        let store = Store::open_in_memory().unwrap();
        let root = tempfile::tempdir().unwrap();
        let (mut state, session) = managed(&store, root.path());
        let artifacts = stamps(root.path(), b"result");
        let goal = state.goals[0].clone();
        state.questions.push(serde_json::from_value(serde_json::json!({
            "id":"uncertain-answer", "goal_id":goal.id,"assignment_id":goal.assignments[0].id,
            "contract_revision":1,"author":"worker","title":"Permission?","context":"Pending operation",
            "options":[],"blocking":true,"state":outcome,"answer":"allow_once","answered_by":"user",
            "source_input":null,"request_id":null,"answer_delivery_id":"native:claimed"
        })).unwrap());
        store.save_assistant(state.revision, state).unwrap();
        assert!(
            store
                .assistant_worker(
                    &session.id,
                    WorkerOperation::Submit {
                        contract_revision: 1,
                        evidence: "checked".into(),
                        artifacts
                    }
                )
                .is_err(),
            "{outcome}"
        );
    }
}

#[test]
fn one_free_slot_cannot_admit_two_independent_waiters() {
    let store = Store::open_in_memory().unwrap();
    let mut state = configured(&store);
    let mut second = state.goals[0].clone();
    second.id = "independent-waiter".into();
    state.goals.push(second);
    let first = apply_decision(&state, &[], dispatch(&state)).unwrap();
    // The first durable intent reserves capacity even before session creation starts.
    let second_decision = AssistantDecision {
        summary: "The other waiter also saw a free slot".into(),
        actions: vec![AssistantAction::Dispatch {
            goal_id: state.goals[1].id.clone(),
            instruction: "Work only after capacity is available".into(),
        }],
    };
    assert!(matches!(
        apply_decision(&first, &[], second_decision),
        Err(codetwo_core::store::StoreError::AssistantConcurrencyLimit)
    ));
    assert_eq!(first.goals[0].assignments.len(), 1);
    assert!(first.goals[1].assignments.is_empty());
}
