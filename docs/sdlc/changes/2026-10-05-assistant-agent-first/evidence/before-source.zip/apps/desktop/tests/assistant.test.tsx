// @ts-nocheck
import { afterEach, expect, test } from "bun:test";

import { Simulate } from "react-dom/test-utils";

import {
  activateDom,
  dom,
  mount,
  click,
  button,
  waitFor,
  flush,
} from "./domTestHarness";
activateDom();
const { AssistantWorkspace } =
  await import("../src/assistant/AssistantWorkspace");
const { I18nProvider } = await import("../src/i18n");
const mounted = [];
afterEach(() => {
  for (const root of mounted.splice(0)) root.unmount();
  dom.document.body.replaceChildren();
});
function render({
  rejectEdits = false,
  coordination = false,
  freshChange = null,
  initialChange = null,
} = {}) {
  const calls = [];
  let snapshot = {
    state: {
      revision: 3,
      settings: {
        enabled: false,
        projects: ["/a", "/b"],
        provider: "codex",
        model: null,
        reasoning_effort: null,
        concurrency: 1,
        turn_limit: 10,
        dispatch_limit: 5,
      },
      goals: [
        {
          id: "g1",
          project_path: "/a",
          title: "Release report",
          acceptance: "Versioned report and checks",
          priority: 1,
          contract_revision: 1,
          dependencies: [],
          status: "active",
          next_step: "Check the report",
          blocker: "",
          assignments: [
            {
              id: "a1",
              session_id: "s1",
              submitted: true,
              taken_over: false,
              owned: true,
              contract_revision: 1,
              confirmed_revision: 1,
              stop_requested: false,
              result: coordination
                ? {
                    id: "result1",
                    contract_revision: 1,
                    evidence: "Versioned report checked",
                    artifacts: [{ path: "report.txt", sha256: "a".repeat(64) }],
                    state: "submitted",
                  }
                : null,
            },
          ],
          verdict: null,
        },
      ],
      messages: [],
      questions: coordination
        ? [
            {
              id: "q1",
              goal_id: "g1",
              assignment_id: "a1",
              contract_revision: 1,
              title: "Which locale?",
              context: "Report language",
              options: ["English", "Chinese"],
              blocking: true,
              state: "open",
              answer: null,
              answered_by: null,
              source_input: null,
            },
          ]
        : [],
      changes: coordination
        ? [
            {
              id: "c1",
              goal_id: "g1",
              from_revision: 1,
              to_revision: 2,
              before_title: "Release report",
              before_acceptance: "Versioned report and checks",
              title: "Chinese report",
              acceptance: "Chinese release summary",
              reason: "Users need Chinese",
              state: "proposed",
              proposed: true,
              remember: false,
              memory_id: null,
            },
          ]
        : [],
      notifications: coordination
        ? [
            {
              id: "n1",
              goal_id: "g1",
              kind: "deliverable",
              title: "Report submitted",
              body: "Waiting for review",
              session_id: "s1",
              reference_id: "result1",
              read: false,
              desktop: "unknown",
            },
          ]
        : [],
      requests: [],
      run: null,
      summary: "Project A is awaiting review",
      attention: null,
      turns: 1,
      dispatches: 1,
    },
    sessions: [],
    memories: [
      {
        id: "m1",
        project_path: "codetwo://chief-of-staff",
        layer: "L1",
        category: "preference",
        content: "Keep reports short",
        origin: "manual",
        active: true,
        editable: true,
        session_id: null,
        updated_at: 1,
      },
    ],
  };
  let snapshotCalls = 0;
  if (initialChange) initialChange(snapshot);
  const api = {
    catalog: async () => [
      [
        { path: "/a", name: "Project A" },
        { path: "/b", name: "Project B" },
      ],
      [],
    ],
    snapshot: async () => {
      if (++snapshotCalls === 2 && freshChange) freshChange(snapshot.state);
      return structuredClone(snapshot);
    },
    edit: async (revision, edit) => {
      calls.push({ revision, edit });
      if (rejectEdits)
        throw new Error("Revision conflict; retry after refreshing");
      if (edit.kind === "takeover") snapshot.state.goals[0].status = "paused";
      if (edit.kind === "answer")
        snapshot.state.questions[0].state = "answered";
      if (edit.kind === "acknowledge")
        snapshot.state.notifications[0].read = true;
      return snapshot.state;
    },
    memory: async (name, args) => {
      calls.push({ name, args });
      if (name === "set_active") snapshot.memories = [];
    },
  };
  mounted.push(
    mount(
      <I18nProvider>
        <AssistantWorkspace
          activity={<p>Real execution view</p>}
          api={api}
          onSelect={(id) => calls.push({ open: id })}
          onClose={() => calls.push({ close: true })}
        />
      </I18nProvider>
    )
  );
  return calls;
}
async function openSelected(section = "Progress") {
  await waitFor(() =>
    expect(
      dom.document.querySelector('[aria-label="Open goal: Release report"]')
    ).not.toBeNull()
  );
  click(dom.document.querySelector('[aria-label="Open goal: Release report"]'));
  await flush();
  if (section !== "Progress") {
    click(button(dom.document.body, section));
    await flush();
  }
}
async function choose(label, value) {
  click(dom.document.querySelector(`[role="combobox"][aria-label="${label}"]`));
  await waitFor(() =>
    expect(
      [...dom.document.querySelectorAll('[role="option"]')].some(
        (e) => e.textContent === value
      )
    ).toBe(true)
  );
  const option = [...dom.document.querySelectorAll('[role="option"]')].find(
    (e) => e.textContent === value
  );
  option.dispatchEvent(
    new dom.window.PointerEvent("pointerdown", {
      bubbles: true,
      pointerType: "mouse",
    })
  );
  click(option);
  await flush();
}
async function newGoal() {
  await waitFor(() =>
    expect(dom.document.body.textContent).toContain("Release report")
  );
  click(button(dom.document.body, "Give a request"));
  await flush();
  click(button(dom.document.body, "Define acceptance"));
  await flush();
  return button(dom.document.body, "Add goal").closest("form");
}
test("project status stays distinct from execution and takeover is explicit", async () => {
  const calls = render();
  await waitFor(() =>
    expect(dom.document.body.textContent).toContain("Release report")
  );
  await openSelected("Manage");
  expect(dom.document.body.textContent).toContain(
    "Versioned report and checks"
  );
  click(button(dom.document.body, "Take over"));
  await waitFor(() =>
    expect(calls.some((c) => c.edit?.kind === "takeover")).toBe(true)
  );
  expect(calls.find((c) => c.edit).revision).toBe(3);
  click(button(dom.document.body, "Open execution"));
  expect(calls).toContainEqual({ open: "s1" });
  expect(calls).toContainEqual({ close: true });
});
test("global memory is inspectable and forgetting refreshes the notebook", async () => {
  const calls = render();
  await waitFor(() =>
    expect(dom.document.body.textContent).toContain("Release report")
  );
  click(button(dom.document.body, "Memory"));
  await waitFor(() =>
    expect(dom.document.body.textContent).toContain("Keep reports short")
  );
  click(button(dom.document.body, "Forget"));
  await waitFor(() =>
    expect(dom.document.body.textContent).not.toContain("Keep reports short")
  );
  expect(calls).toContainEqual({
    name: "set_active",
    args: { id: "m1", value: false },
  });
  click(button(dom.document.body, "Execution"));
  await waitFor(() =>
    expect(dom.document.body.textContent).toContain("Real execution view")
  );
});

function change(element, value) {
  element.value = value;
  Simulate.change(element);
}

test("a new goal follows the visible project filter and clears only after saving", async () => {
  const calls = render();
  await waitFor(() =>
    expect(dom.document.body.textContent).toContain("Release report")
  );
  await newGoal();
  await choose("Project", "Project B");
  const form = button(dom.document.body, "Add goal").closest("form");
  change(form.querySelector('input[data-slot="input"]'), "Ship project B");
  change(form.querySelector("textarea"), "Tests and release report");
  await flush();
  form.dispatchEvent(
    new dom.window.Event("submit", { bubbles: true, cancelable: true })
  );
  await waitFor(() =>
    expect(calls.some((c) => c.edit?.kind === "goal")).toBe(true)
  );
  expect(calls.find((c) => c.edit?.kind === "goal").edit).toMatchObject({
    project_path: "/b",
    title: "Ship project B",
    acceptance: "Tests and release report",
  });
  await waitFor(() =>
    expect(form.querySelector('input[data-slot="input"]').value).toBe("")
  );
  expect(form.querySelector("textarea").value).toBe("");
});

test("a rejected goal save keeps the draft available for retry", async () => {
  render({ rejectEdits: true });
  await waitFor(() =>
    expect(dom.document.body.textContent).toContain("Release report")
  );
  const form = await newGoal();
  change(form.querySelector('input[data-slot="input"]'), "Keep this goal");
  change(form.querySelector("textarea"), "Keep this acceptance");
  await flush();
  form.dispatchEvent(
    new dom.window.Event("submit", { bubbles: true, cancelable: true })
  );
  await waitFor(() =>
    expect(dom.document.querySelector('[role="alert"]').textContent).toContain(
      "Revision conflict"
    )
  );
  expect(form.querySelector('input[data-slot="input"]').value).toBe(
    "Keep this goal"
  );
  expect(form.querySelector("textarea").value).toBe("Keep this acceptance");
});

test("inbox routes a blocking answer and a requirement decision to their exact records", async () => {
  const calls = render({ coordination: true });
  await waitFor(() =>
    expect(dom.document.body.textContent).toContain("Release report")
  );
  click(button(dom.document.body, "Inbox (3)"));
  await waitFor(() =>
    expect(dom.document.body.textContent).toContain("Which locale?")
  );
  click(dom.document.querySelector('[aria-label="Answer: Which locale?"]'));
  await flush();
  const answer = dom.document.querySelector('input[value="Chinese"]');
  click(answer);
  await flush();
  click(button(dom.document.body, "Send answer"));
  await waitFor(() =>
    expect(
      calls.some(
        (c) => c.edit?.question_id === "q1" && c.edit.answer === "Chinese"
      )
    ).toBe(true)
  );
  await waitFor(() =>
    expect(dom.document.body.textContent).not.toContain("Which locale?")
  );
  click(
    dom.document.querySelector('[aria-label="Review change: Chinese report"]')
  );
  await flush();
  const remember = dom.document.querySelector('input[type="checkbox"]');
  click(remember);
  await flush();
  click(button(dom.document.body, "Apply change"));
  await waitFor(() =>
    expect(
      calls.some((c) => c.edit?.change_id === "c1" && c.edit.remember === true)
    ).toBe(true)
  );
  await flush();
  click(button(dom.document.body, "Mark read"));
  await waitFor(() =>
    expect(calls.some((c) => c.edit?.notification_id === "n1")).toBe(true)
  );
});
test("messages, stop and rework are separate operations and failed sends retain drafts", async () => {
  const calls = render({ coordination: true, rejectEdits: true });
  await openSelected("Updates");
  await waitFor(() =>
    expect(dom.document.body.textContent).toContain("Message worker")
  );
  const label = [...dom.document.querySelectorAll("label")].find((e) =>
    e.textContent.includes("Message worker")
  );
  change(label.querySelector("textarea"), "Keep the existing section");
  await flush();
  click(button(dom.document.body, "Send message"));
  await waitFor(() =>
    expect(dom.document.body.textContent).toContain("Revision conflict")
  );
  expect(label.querySelector("textarea").value).toBe(
    "Keep the existing section"
  );
  expect(
    calls.some((c) => c.edit?.kind === "message" && c.edit.goal_id === "g1")
  ).toBe(true);
  click(button(dom.document.body, "Request stop"));
  await waitFor(() =>
    expect(calls.some((c) => c.edit?.operation === "stop")).toBe(true)
  );
  await flush();
  click(button(dom.document.body, "Progress"));
  await flush();
  const review = [...dom.document.querySelectorAll("label")].find((e) =>
    e.textContent.includes("Review evidence")
  );
  change(review.querySelector("textarea"), "Add concrete regression evidence");
  await flush();
  click(button(dom.document.body, "Request rework"));
  await waitFor(() =>
    expect(
      calls.some(
        (c) =>
          c.edit?.verdict === "rework" &&
          c.edit.evidence === "Add concrete regression evidence"
      )
    ).toBe(true)
  );
});

test("unrelated worker activity does not reject a message composed against the same goal", async () => {
  const calls = render({
    freshChange: (state) => {
      state.revision = 4;
      state.turns += 1;
    },
  });
  await openSelected("Updates");
  await waitFor(() =>
    expect(dom.document.body.textContent).toContain("Message worker")
  );
  const label = [...dom.document.querySelectorAll("label")].find((e) =>
    e.textContent.includes("Message worker")
  );
  change(label.querySelector("textarea"), "Keep the existing section");
  await flush();
  click(button(dom.document.body, "Send message"));
  await waitFor(() =>
    expect(calls.some((c) => c.edit?.kind === "message")).toBe(true)
  );
  expect(calls.find((c) => c.edit?.kind === "message").revision).toBe(4);
});

test("a new requirement while composing retains the draft for an explicit retry", async () => {
  const calls = render({
    freshChange: (state) => {
      state.revision = 4;
      state.goals[0].contract_revision = 2;
    },
  });
  await openSelected("Updates");
  await waitFor(() =>
    expect(dom.document.body.textContent).toContain("Message worker")
  );
  const label = [...dom.document.querySelectorAll("label")].find((e) =>
    e.textContent.includes("Message worker")
  );
  change(label.querySelector("textarea"), "Keep the existing section");
  await flush();
  click(button(dom.document.body, "Send message"));
  await waitFor(() =>
    expect(dom.document.body.textContent).toContain("This target changed")
  );
  expect(calls.some((c) => c.edit?.kind === "message")).toBe(false);
  expect(label.querySelector("textarea").value).toBe(
    "Keep the existing section"
  );
});

test("a polled replacement deliverable cannot reuse an earlier review draft", async () => {
  const calls = render({
    coordination: true,
    freshChange: (state) => {
      state.revision = 4;
      state.goals[0].assignments[0].result.id = "result2";
      state.goals[0].assignments[0].result.evidence =
        "New deliverable inspected separately";
    },
  });
  await openSelected("Progress");
  await waitFor(() =>
    expect(dom.document.body.textContent).toContain("Review evidence")
  );
  const label = [...dom.document.querySelectorAll("label")].find((e) =>
    e.textContent.includes("Review evidence")
  );
  change(label.querySelector("textarea"), "Review of result1");
  await flush();
  await waitFor(
    () =>
      expect(dom.document.body.textContent).toContain(
        "New deliverable inspected separately"
      ),
    6500
  );
  click(button(dom.document.body, "Accept"));
  await waitFor(() =>
    expect(dom.document.body.textContent).toContain("This target changed")
  );
  expect(calls.some((c) => c.edit?.kind === "review")).toBe(false);
  expect(label.querySelector("textarea").value).toBe("Review of result1");
  click(button(dom.document.body, "Reviewed; continue with latest version"));
  await flush();
  click(button(dom.document.body, "Accept"));
  await waitFor(() =>
    expect(calls.some((c) => c.edit?.kind === "review")).toBe(true)
  );
}, 12000);

test("forgetting a memory exposes affected assignments and sends a distinct correction", async () => {
  const calls = render();
  await waitFor(() =>
    expect(dom.document.body.textContent).toContain("Release report")
  );
  click(button(dom.document.body, "Memory"));
  await waitFor(() =>
    expect(dom.document.body.textContent).toContain("Keep reports short")
  );
  click(button(dom.document.body, "Forget"));
  await waitFor(() =>
    expect(dom.document.body.textContent).toContain(
      "These assignments may have used"
    )
  );
  const form = button(dom.document.body, "Send memory correction").closest(
    "form"
  );
  change(
    form.querySelector("textarea"),
    "The previous length preference is withdrawn; follow the current acceptance criteria."
  );
  await flush();
  form.dispatchEvent(
    new dom.window.Event("submit", { bubbles: true, cancelable: true })
  );
  await waitFor(() =>
    expect(
      calls.some((c) => c.edit?.kind === "message" && c.edit.goal_id === "g1")
    ).toBe(true)
  );
  expect(dom.document.body.textContent).toContain("Correction recorded");
});

test("independent review sessions expose scoped progress and failure", async () => {
  const calls = render({
    initialChange(snapshot) {
      snapshot.state.scoped_runs = [
        {
          scope: "g1",
          run: { id: "r1", session_id: "review-a" },
          state: "running",
          summary: "",
          error: null,
        },
        {
          scope: "request-b",
          run: { id: "r2", session_id: null },
          state: "failed",
          summary: "",
          error: "B needs a decision",
        },
      ];
    },
  });
  await waitFor(() =>
    expect(dom.document.body.textContent).toContain("B needs a decision")
  );
  await openSelected();
  expect(dom.document.body.textContent).toContain("Reviewing");
  click(button(dom.document.body, "Open review"));
  expect(calls).toContainEqual({ open: "review-a" });
});

test("unknown answer remains visible and cannot be blindly replayed", async () => {
  const calls = render({
    coordination: true,
    initialChange(snapshot) {
      snapshot.state.questions[0].state = "delivery_unknown";
    },
  });
  await waitFor(() =>
    expect(dom.document.body.textContent).toContain("Release report")
  );
  click(button(dom.document.body, "Inbox (3)"));
  await waitFor(() =>
    expect(dom.document.body.textContent).toContain("Answer outcome unknown")
  );
  expect(button(dom.document.body, "Reopen clarification").disabled).toBe(true);
  expect(calls.some((c) => c.edit?.kind === "retry_question")).toBe(false);
});

test("overview removes native disclosure and per-goal forms; sections keep draft and stop access", async () => {
  const calls = render({ coordination: true });
  await waitFor(() =>
    expect(dom.document.body.textContent).toContain("Release report")
  );
  expect(dom.document.querySelectorAll("details, summary, select").length).toBe(
    0
  );
  expect(dom.document.querySelectorAll("textarea").length).toBe(0);
  expect(dom.document.body.textContent).not.toContain("Take over");
  await openSelected("Updates");
  const input = button(dom.document.body, "Send message")
    .closest("form")
    .querySelector("textarea");
  change(input, "Keep this draft across sections");
  await flush();
  click(button(dom.document.body, "Manage"));
  await flush();
  expect(input.closest("[hidden]")).not.toBeNull();
  click(button(dom.document.body, "Updates"));
  await flush();
  expect(input.value).toBe("Keep this draft across sections");
  expect(
    button(dom.document.body, "Request stop").closest("[hidden]")
  ).toBeNull();
  expect(calls.some((c) => c.edit)).toBe(false);
});

test("settings and memory composition are on demand and do not mutate on navigation", async () => {
  const calls = render();
  await waitFor(() =>
    expect(dom.document.body.textContent).toContain("Release report")
  );
  click(button(dom.document.body, "Configure"));
  await flush();
  const advanced = dom.document.querySelector("#assistant-advanced-settings");
  expect(advanced.hidden).toBe(true);
  expect(dom.document.body.textContent).not.toContain("Release report");
  click(button(dom.document.body, "Advanced settings"));
  await flush();
  expect(advanced.hidden).toBe(false);
  click(button(dom.document.body, "Memory"));
  await flush();
  const remember = button(dom.document.body, "Remember");
  expect(remember.closest("[hidden]")).not.toBeNull();
  click(button(dom.document.body, "Add memory"));
  await flush();
  expect(remember.closest("[hidden]")).toBeNull();
  expect(calls.some((c) => c.edit || c.name)).toBe(false);
});

test("inbox opens only the selected decision form", async () => {
  render({ coordination: true });
  await waitFor(() =>
    expect(dom.document.body.textContent).toContain("Release report")
  );
  click(button(dom.document.body, "Inbox (3)"));
  await flush();
  expect(dom.document.querySelectorAll("form").length).toBe(0);
  click(dom.document.querySelector('[aria-label="Answer: Which locale?"]'));
  await flush();
  expect(dom.document.querySelectorAll("form").length).toBe(1);
  click(
    dom.document.querySelector('[aria-label="Review change: Chinese report"]')
  );
  await flush();
  expect(dom.document.querySelector('input[value="Chinese"]')).toBeNull();
  expect(button(dom.document.body, "Apply change")).toBeDefined();
});

test("request entry records the selected project and confirms submission", async () => {
  const calls = render();
  await waitFor(() =>
    expect(dom.document.body.textContent).toContain("Release report")
  );
  click(button(dom.document.body, "Give a request"));
  await flush();
  await choose("Request project", "Project B");
  const form = button(dom.document.body, "Submit request").closest("form");
  change(form.querySelector("textarea"), "Prepare the project B release brief");
  await flush();
  form.dispatchEvent(
    new dom.window.Event("submit", { bubbles: true, cancelable: true })
  );
  await waitFor(() =>
    expect(calls.find((c) => c.edit?.kind === "request")?.edit).toMatchObject({
      project_path: "/b",
      content: "Prepare the project B release brief",
    })
  );
  await waitFor(() =>
    expect(dom.document.body.textContent).toContain("Request recorded")
  );
  expect(form.querySelector("textarea").value).toBe("");
});
