import { call } from "../bridge";
import type {
  MemoryRecord,
  SessionInfo,
  Project,
  ProviderInfo,
  PendingInput,
} from "../bridge";

export const GLOBAL_MEMORY = "codetwo://chief-of-staff";
export interface AssistantSettings {
  enabled: boolean;
  projects: string[];
  provider: string;
  model: string | null;
  reasoning_effort: string | null;
  concurrency: number;
  turn_limit: number;
  dispatch_limit: number;
}
export interface Goal {
  id: string;
  project_path: string;
  title: string;
  acceptance: string;
  priority: number;
  status: "active" | "paused" | "needs_attention" | "completed" | "cancelled";
  contract_revision: number;
  dependencies: string[];
  next_step: string;
  blocker: string;
  assignments: {
    id: string;
    session_id: string | null;
    submitted: boolean;
    taken_over: boolean;
    owned: boolean;
    contract_revision: number;
    confirmed_revision: number;
    stop_requested: boolean;
    prior_results: {
      id: string;
      contract_revision: number;
      evidence: string;
      artifacts: { path: string; sha256: string }[];
      state: string;
    }[];
    result: {
      id: string;
      contract_revision: number;
      evidence: string;
      artifacts: { path: string; sha256: string }[];
      state: string;
    } | null;
  }[];
  verdict: {
    session_id: string;
    activity_revision: number;
    evidence: string;
    artifacts: { path: string; sha256: string }[];
  } | null;
}
export interface AssistantState {
  revision: number;
  settings: AssistantSettings | null;
  goals: Goal[];
  run: { session_id: string | null } | null;
  scoped_runs?: {
    scope: string;
    run: { id: string; session_id: string | null };
    state: string;
    summary: string;
    error: string | null;
  }[];
  summary: string;
  attention: string | null;
  messages: CoordinationMessage[];
  questions: CoordinationQuestion[];
  changes: RequirementChange[];
  notifications: AssistantNotification[];
  requests: {
    id: string;
    project_path: string;
    content: string;
    handled: boolean;
  }[];
  turns: number;
  dispatches: number;
  /** Absent in snapshots written before the conversation feature. */
  conversation?: ConversationTurn[];
  memory_proposals?: MemoryProposal[];
}
export interface ConversationTurn {
  id: string;
  created_at: string | number;
  author: "user" | "assistant";
  content: string;
  reply_to: string | null;
  project_paths: string[];
  status: "recorded" | "reviewing" | "handled" | "failed" | "unknown";
  goal_ids: string[];
  question_ids: string[];
  error: string | null;
  source_run_id: string | null;
}
export interface MemoryProposal {
  id: string;
  turn_id: string;
  project_path: string;
  category: string;
  content: string;
  content_hash: string;
  state: "proposed" | "confirmed" | "rejected" | "failed";
  memory_id: string | null;
  error: string | null;
}
export interface CoordinationMessage {
  id: string;
  goal_id: string;
  assignment_id: string;
  contract_revision: number;
  mode: string;
  author: string;
  content: string;
  state: string;
  outcome: string;
  confirmed: boolean;
}
export interface CoordinationQuestion {
  id: string;
  goal_id: string;
  assignment_id: string;
  contract_revision: number;
  title: string;
  context: string;
  options: string[];
  blocking: boolean;
  state: string;
  answer: string | null;
  answered_by: string | null;
  source_input: PendingInput | null;
}
export interface RequirementChange {
  id: string;
  goal_id: string;
  from_revision: number;
  to_revision: number;
  before_title: string;
  before_acceptance: string;
  title: string;
  acceptance: string;
  reason: string;
  state: string;
  proposed: boolean;
  remember: boolean;
  memory_id: string | null;
}
export interface AssistantNotification {
  id: string;
  goal_id: string;
  kind: string;
  title: string;
  body: string;
  session_id: string | null;
  reference_id: string;
  read: boolean;
  desktop: string;
}
export interface AssistantSnapshot {
  state: AssistantState;
  sessions: SessionInfo[];
  memories: MemoryRecord[];
}
export const assistantApi = {
  catalog: async () =>
    await Promise.all([
      call<Project[]>("projects.list", null, null),
      call<ProviderInfo[]>("providers.list", {}, null),
    ]),
  snapshot: async () =>
    await call<AssistantSnapshot>("assistant.snapshot", null, null),
  edit: async (revision: number, edit: unknown) =>
    await call<AssistantState>("assistant.edit", { revision, edit }, null),
  memory: async (name: string, args: unknown) =>
    await call(`memory.${name}`, args, null),
};

export function sameGoalTarget(old: Goal, current: Goal, review = false) {
  return (
    old.contract_revision === current.contract_revision &&
    old.priority === current.priority &&
    old.status === current.status &&
    old.assignments.at(-1)?.id === current.assignments.at(-1)?.id &&
    old.assignments.at(-1)?.taken_over ===
      current.assignments.at(-1)?.taken_over &&
    (!review ||
      old.assignments.at(-1)?.result?.id ===
        current.assignments.at(-1)?.result?.id)
  );
}

/** Unrelated worker activity may advance the global revision while a user fills a form. */
export function sameEditTarget(
  before: AssistantState,
  after: AssistantState,
  action: unknown
) {
  if (action == null || typeof action !== "object" || !("kind" in action))
    return false;
  if (action.kind === "settings")
    return JSON.stringify(before.settings) === JSON.stringify(after.settings);
  if ("proposal_id" in action) {
    const old = before.memory_proposals?.find(
      (p) => p.id === action.proposal_id
    );
    const current = after.memory_proposals?.find(
      (p) => p.id === action.proposal_id
    );
    return (
      old != null &&
      current != null &&
      current.state === "proposed" &&
      old.state === current.state &&
      old.content_hash === current.content_hash &&
      (!("content_hash" in action) ||
        action.content_hash === current.content_hash)
    );
  }
  const questionId =
    "question_id" in action
      ? action.question_id
      : "answers_question" in action &&
          typeof action.answers_question === "string"
        ? action.answers_question
        : null;
  if (questionId != null) {
    const old = before.questions?.find((q) => q.id === questionId);
    const current = after.questions?.find((q) => q.id === questionId);
    return (
      old != null &&
      current != null &&
      old.state === current.state &&
      old.contract_revision === current.contract_revision &&
      old.assignment_id === current.assignment_id
    );
  }
  const id =
    "goal_id" in action ? action.goal_id : "id" in action ? action.id : null;
  if (id == null) return true;
  const old = before.goals.find((g) => g.id === id);
  const current = after.goals.find((g) => g.id === id);
  return (
    old != null &&
    current != null &&
    sameGoalTarget(old, current, action.kind === "review") &&
    (action.kind !== "goal" || old.priority === current.priority)
  );
}
