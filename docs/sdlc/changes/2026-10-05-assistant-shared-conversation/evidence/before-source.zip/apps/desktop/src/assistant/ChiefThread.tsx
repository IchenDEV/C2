import { useEffect, useRef, useState } from "react";

import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";

import { MarkdownContent } from "../session/MarkdownContent";
import { GLOBAL_MEMORY } from "./api";
import type { AssistantState, ConversationTurn, Goal } from "./api";
import {
  DeliveryCard,
  GoalCard,
  intakeLabel,
  MemoryProposalCard,
  NotificationCard,
  ProposalCard,
  QuestionCard,
} from "./ThreadCards";
import type { CardContext } from "./ThreadCards";

const OPEN_QUESTION = new Set(["open", "expired", "delivery_unknown"]);
const FOLLOW_BOTTOM_PX = 80;

function timeLabel(value: string | number) {
  const date = new Date(
    typeof value === "number" && value < 1e12 ? value * 1000 : value
  );
  return Number.isNaN(date.getTime())
    ? ""
    : date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
}

/** One client id per distinct message, kept across failed attempts so Core can deduplicate. */
function newTurnId() {
  return globalThis.crypto.randomUUID();
}

export function ChiefThread({
  state,
  managed,
  active,
  ctx,
  onConfigure,
}: {
  state: AssistantState;
  managed: { path: string; name: string }[];
  active: boolean;
  ctx: CardContext;
  onConfigure: () => void;
}) {
  const { zh } = ctx;
  const [draft, setDraft] = useState("");
  const [hints, setHints] = useState<string[]>([]);
  const [sending, setSending] = useState(false);
  const [notSent, setNotSent] = useState(false);
  const [goalsOpen, setGoalsOpen] = useState(false);
  const [earlierOpen, setEarlierOpen] = useState(false);
  const [scopeOpen, setScopeOpen] = useState(false);
  const attempt = useRef<{ id: string; key: string } | null>(null);
  const stream = useRef<HTMLDivElement>(null);
  const stick = useRef(true);
  const savedTop = useRef(0);

  const turns = state.conversation ?? [];
  const goalById = new Map(state.goals.map((g) => [g.id, g]));
  const shown = new Set<string>();
  const questionById = new Map((state.questions ?? []).map((q) => [q.id, q]));
  const proposals = state.memory_proposals ?? [];

  const refs = (turn: ConversationTurn) => (
    <>
      {turn.goal_ids.map((id) => {
        const g = goalById.get(id);
        if (!g || shown.has(`g:${id}`)) return null;
        shown.add(`g:${id}`);
        return (
          <div key={`g:${id}`} className="space-y-2">
            <GoalCard goal={g} ctx={ctx} />
            <DeliveryCard goal={g} ctx={ctx} />
          </div>
        );
      })}
      {turn.question_ids.map((id) => {
        const q = questionById.get(id);
        if (!q || !OPEN_QUESTION.has(q.state) || shown.has(`q:${id}`))
          return null;
        shown.add(`q:${id}`);
        return <QuestionCard key={`q:${id}`} question={q} ctx={ctx} />;
      })}
      {proposals
        .filter((p) => p.turn_id === turn.id)
        .map((p) => {
          shown.add(`m:${p.id}`);
          return (
            <MemoryProposalCard
              key={p.id}
              proposal={p}
              global={GLOBAL_MEMORY}
              ctx={ctx}
            />
          );
        })}
    </>
  );

  const turnViews = turns.map((turn) => {
    const mine = turn.author === "user";
    const run =
      state.scoped_runs?.find((r) => r.run.id === turn.source_run_id) ??
      state.scoped_runs?.findLast((r) => r.scope === `turn:${turn.id}`);
    return (
      <div
        key={turn.id}
        className={`flex flex-col gap-2 ${mine ? "items-end" : "items-start"}`}
      >
        <div
          className={`rounded-control max-w-[min(100%,40rem)] min-w-0 space-y-1 p-3 ${mine ? "bg-fill-selected" : "bg-fill-quiet"}`}
        >
          {mine ? (
            <p className="text-prose break-words whitespace-pre-wrap">
              {turn.content}
            </p>
          ) : (
            <MarkdownContent text={turn.content} />
          )}
          <p className="text-caption text-muted-foreground">
            {mine
              ? `${intakeLabel(turn.status, zh)} · ${timeLabel(turn.created_at)}`
              : `${zh ? "幕僚" : "Chief of staff"} · ${timeLabel(turn.created_at)}`}
          </p>
          {mine && (turn.error ?? "") !== "" && (
            <p role="status" className="text-warning text-callout break-words">
              {turn.error}
            </p>
          )}
          {mine && run?.run.session_id != null && run.run.session_id !== "" && (
            <Button
              variant="ghost"
              onClick={() => ctx.onSession(run.run.session_id!)}
            >
              {zh ? "打开处理会话" : "Open handling session"}
            </Button>
          )}
        </div>
        <div className="w-full space-y-2">{refs(turn)}</div>
      </div>
    );
  });

  // Live records not already placed under a message.
  const liveGoals = state.goals.filter(
    (g) => g.status !== "completed" && g.status !== "cancelled"
  );
  const tail = {
    questions: (state.questions ?? []).filter(
      (q) => OPEN_QUESTION.has(q.state) && !shown.has(`q:${q.id}`)
    ),
    changes: (state.changes ?? []).filter(
      (c) => c.proposed && c.state === "proposed"
    ),
    memory: proposals.filter(
      (p) =>
        !shown.has(`m:${p.id}`) &&
        (p.state === "proposed" || p.state === "failed")
    ),
    deliveries: state.goals.filter(
      (g) =>
        g.assignments.at(-1)?.result?.state === "submitted" &&
        !shown.has(`g:${g.id}`)
    ),
    notes: (state.notifications ?? []).filter((n) => !n.read),
    goals: liveGoals.filter((g) => !shown.has(`g:${g.id}`)),
    // Failed reviews that belong to no goal and no message would otherwise vanish.
    reviews: (state.scoped_runs ?? []).filter(
      (r) =>
        (r.error ?? "") !== "" &&
        !goalById.has(r.scope) &&
        !turns.some(
          (t) => t.source_run_id === r.run.id || r.scope === `turn:${t.id}`
        )
    ),
  };
  const tailCount = Object.values(tail).reduce((n, v) => n + v.length, 0);
  const notified = new Set<string>();
  const latestNotes = tail.notes
    .toReversed()
    .filter((n) => {
      const key = n.goal_id || n.id;
      if (notified.has(key)) return false;
      notified.add(key);
      return true;
    })
    .toReversed();
  const latestIds = new Set(latestNotes.map((n) => n.id));
  const earlierNotes = tail.notes.filter((n) => !latestIds.has(n.id));
  const bottomKey = `${turns.length}:${tailCount}`;

  useEffect(() => {
    const el = stream.current;
    if (el && active && stick.current) el.scrollTop = el.scrollHeight;
  }, [bottomKey, active]);
  useEffect(() => {
    // A hidden panel loses its scroll offset; restore it when the thread returns.
    const el = stream.current;
    if (el && active && !stick.current) el.scrollTop = savedTop.current;
  }, [active]);

  const paths = hints.toSorted();
  const content = draft.trim();
  const send = async () => {
    if (!content || sending || ctx.busy || managed.length === 0) return;
    const key = JSON.stringify([content, paths]);
    if (attempt.current?.key !== key)
      attempt.current = { id: newTurnId(), key };
    setSending(true);
    setNotSent(false);
    stick.current = true;
    const saved = await ctx.edit({
      kind: "say",
      turn_id: attempt.current.id,
      content,
      ...(paths.length ? { project_paths: paths } : {}),
    });
    setSending(false);
    if (saved) {
      attempt.current = null;
      setDraft((now) => (now.trim() === content ? "" : now));
      setHints((now) =>
        JSON.stringify(now.toSorted()) === JSON.stringify(paths) ? [] : now
      );
    } else setNotSent(true);
  };

  return (
    <div
      hidden={!active}
      className="flex min-h-0 flex-1 flex-col"
      aria-label={zh ? "与幕僚的对话" : "Conversation with chief of staff"}
      role="region"
    >
      <div
        ref={stream}
        className="min-h-0 flex-1 overflow-y-auto"
        onScroll={(e) => {
          if (!active) return;
          const el = e.currentTarget;
          savedTop.current = el.scrollTop;
          stick.current =
            el.scrollHeight - el.scrollTop - el.clientHeight < FOLLOW_BOTTOM_PX;
        }}
      >
        <div className="mx-auto flex w-full max-w-3xl flex-col gap-4 px-4 py-6 sm:px-6">
          <h2 tabIndex={-1} className="text-section-title font-semibold">
            {zh ? "和幕僚说" : "Talk to your chief of staff"}
          </h2>
          {turns.length === 0 && (
            <p className="text-prose text-muted-foreground">
              {managed.length === 0
                ? zh
                  ? "先在设置里选择幕僚可以跟进的项目。"
                  : "Choose the projects the chief of staff may follow in Settings first."
                : (state.summary ?? "") ||
                  (zh
                    ? "直接说想问的、想推进的事。可以一次交代多个项目。"
                    : "Ask, discuss, or hand over work in plain words. One message can cover several projects.")}
            </p>
          )}
          {managed.length === 0 && (
            <Button
              variant="secondary"
              className="self-start"
              onClick={onConfigure}
            >
              {zh ? "打开设置" : "Open settings"}
            </Button>
          )}
          {turnViews}
          {state.attention != null && state.attention !== "" && (
            <p role="status" className="text-warning text-prose">
              {state.attention}
            </p>
          )}
          {tailCount > 0 && (
            <section className="space-y-3" aria-label={zh ? "当前" : "Now"}>
              <h3 className="text-callout text-muted-foreground">
                {zh ? "需要你，或刚有进展" : "Needs you, or just moved"}
              </h3>
              {tail.questions.map((q) => (
                <QuestionCard key={q.id} question={q} ctx={ctx} />
              ))}
              {tail.changes.map((c) => (
                <ProposalCard key={c.id} change={c} ctx={ctx} />
              ))}
              {tail.memory.map((p) => (
                <MemoryProposalCard
                  key={p.id}
                  proposal={p}
                  global={GLOBAL_MEMORY}
                  ctx={ctx}
                />
              ))}
              {tail.deliveries.map((g) => (
                <DeliveryCard key={g.id} goal={g} ctx={ctx} />
              ))}
              {tail.reviews.map((r) => (
                <div key={r.run.id} className="text-warning space-y-2">
                  <p className="text-prose break-words">{r.error}</p>
                  {r.run.session_id != null && r.run.session_id !== "" && (
                    <Button
                      variant="ghost"
                      onClick={() => ctx.onSession(r.run.session_id!)}
                    >
                      {zh ? "打开复查会话" : "Open review"}
                    </Button>
                  )}
                </div>
              ))}
              {latestNotes.map((n) => (
                <NotificationCard key={n.id} notification={n} ctx={ctx} />
              ))}
              {earlierNotes.length > 0 && (
                <>
                  <Button
                    variant="ghost"
                    aria-expanded={earlierOpen}
                    onClick={() => setEarlierOpen(!earlierOpen)}
                  >
                    {zh
                      ? `更早的进展（${earlierNotes.length}）`
                      : `Earlier updates (${earlierNotes.length})`}
                  </Button>
                  {earlierOpen &&
                    earlierNotes.map((n) => (
                      <NotificationCard key={n.id} notification={n} ctx={ctx} />
                    ))}
                </>
              )}
              {tail.goals.length > 0 && (
                <>
                  <Button
                    variant="ghost"
                    aria-expanded={goalsOpen}
                    onClick={() => setGoalsOpen(!goalsOpen)}
                  >
                    {zh
                      ? `正在跟进 ${tail.goals.length} 项`
                      : `${tail.goals.length} in progress`}
                  </Button>
                  {goalsOpen &&
                    tail.goals
                      .toSorted((a: Goal, b: Goal) => a.priority - b.priority)
                      .map((g) => <GoalCard key={g.id} goal={g} ctx={ctx} />)}
                </>
              )}
            </section>
          )}
        </div>
      </div>
      <form
        className="border-border bg-background shrink-0 border-t"
        onSubmit={(e) => {
          e.preventDefault();
          void send();
        }}
      >
        <div className="mx-auto grid w-full max-w-3xl gap-2 px-4 py-3 sm:px-6">
          {managed.length > 0 && (
            <Button
              type="button"
              variant="ghost"
              className="justify-self-start"
              aria-expanded={scopeOpen}
              onClick={() => setScopeOpen(!scopeOpen)}
            >
              {hints.length
                ? zh
                  ? `限定 ${hints.length} 个项目`
                  : `${hints.length} selected projects`
                : zh
                  ? "项目范围（可选）"
                  : "Project scope (optional)"}
            </Button>
          )}
          {managed.length > 0 && scopeOpen && (
            <div
              className="flex flex-wrap items-center gap-2"
              role="group"
              aria-label={zh ? "范围提示（可选）" : "Scope hint (optional)"}
            >
              <span className="text-callout text-muted-foreground">
                {hints.length
                  ? zh
                    ? "仅限："
                    : "Only:"
                  : zh
                    ? "范围（可选，不选由幕僚判断）："
                    : "Scope (optional; otherwise the chief decides):"}
              </span>
              {managed.map((p) => (
                <Button
                  key={p.path}
                  type="button"
                  size="compact"
                  variant={hints.includes(p.path) ? "secondary" : "ghost"}
                  aria-pressed={hints.includes(p.path)}
                  onClick={() =>
                    setHints((now) =>
                      now.includes(p.path)
                        ? now.filter((v) => v !== p.path)
                        : [...now, p.path]
                    )
                  }
                >
                  {p.name}
                </Button>
              ))}
            </div>
          )}
          <Textarea
            aria-label={zh ? "给幕僚的消息" : "Message to chief of staff"}
            maxLength={16_000}
            rows={3}
            placeholder={
              zh
                ? "问进展、聊取舍，或交办 A 和 B 的事…"
                : "Ask for progress, discuss trade-offs, or hand over work for A and B…"
            }
            value={draft}
            onChange={(e) => {
              setDraft(e.target.value);
              setNotSent(false);
            }}
            onKeyDown={(e) => {
              if (e.key === "Enter" && (e.metaKey || e.ctrlKey)) {
                e.preventDefault();
                void send();
              }
            }}
          />
          <div className="flex flex-wrap items-center gap-3">
            <Button
              type="submit"
              disabled={!content || sending || ctx.busy || managed.length === 0}
            >
              {zh ? "发送" : "Send"}
            </Button>
            {notSent && (
              <span role="status" className="text-warning text-callout">
                {zh
                  ? "未能发送，草稿已保留；重试使用同一条消息。"
                  : "Not sent. Your draft is kept; retrying resends the same message."}
              </span>
            )}
            {state.settings?.enabled !== true && (
              <span className="text-callout text-muted-foreground">
                {zh
                  ? "跟进已暂停，消息会先记录。"
                  : "Follow-up is paused; messages are recorded first."}
              </span>
            )}
          </div>
        </div>
      </form>
    </div>
  );
}
