// @ts-nocheck
import { afterEach, expect, test } from "bun:test";

import { Simulate } from "react-dom/test-utils";

import {
  activateDom,
  button,
  click,
  dom,
  flush,
  mount,
  waitFor,
} from "./domTestHarness";
activateDom();
const { AssistantWorkspace } =
  await import("../src/assistant/AssistantWorkspace");
const { sameEditTarget } = await import("../src/assistant/api");
const { I18nProvider } = await import("../src/i18n");
const mounted = [];
afterEach(() => {
  for (const root of mounted.splice(0)) root.unmount();
  dom.document.body.replaceChildren();
});

const goal = (over = {}) => ({
  id: "g1",
  project_path: "/a",
  title: "Login fix",
  acceptance: "Users can sign in",
  priority: 1,
  contract_revision: 2,
  dependencies: [],
  status: "active",
  next_step: "Run the checks",
  blocker: "",
  assignments: [
    {
      id: "a1",
      session_id: "s1",
      submitted: true,
      taken_over: false,
      owned: true,
      contract_revision: 2,
      confirmed_revision: 1,
      stop_requested: false,
      prior_results: [],
      result: null,
    },
  ],
  verdict: null,
  ...over,
});
const question = (over = {}) => ({
  id: "q1",
  goal_id: "g1",
  assignment_id: "a1",
  contract_revision: 2,
  title: "Which locale?",
  context: "Report language",
  options: ["English", "Chinese"],
  blocking: true,
  state: "open",
  answer: null,
  answered_by: null,
  source_input: null,
  ...over,
});
const turn = (over = {}) => ({
  id: "t1",
  created_at: "2026-10-05T08:00:00Z",
  author: "user",
  content: "Where is login?",
  reply_to: null,
  project_paths: [],
  status: "recorded",
  goal_ids: [],
  question_ids: [],
  error: null,
  source_run_id: null,
  ...over,
});
const proposal = (over = {}) => ({
  id: "p1",
  turn_id: "t1",
  project_path: "/a",
  category: "preference",
  content: "Release notes are written in Chinese",
  content_hash: "abcdef0123456789",
  state: "proposed",
  memory_id: null,
  error: null,
  ...over,
});

function render({
  state = {},
  rejectEdits = 0,
  onPoll = null,
  legacy = false,
  beforeEdit = null,
} = {}) {
  const calls = [];
  const snapshot = {
    state: {
      revision: 5,
      settings: {
        enabled: true,
        projects: ["/a", "/b"],
        provider: "codex",
        model: null,
        reasoning_effort: null,
        concurrency: 1,
        turn_limit: 10,
        dispatch_limit: 5,
      },
      goals: [goal()],
      messages: [],
      questions: [],
      changes: [],
      notifications: [],
      requests: [],
      run: null,
      summary: "",
      attention: null,
      turns: 0,
      dispatches: 0,
      conversation: [],
      memory_proposals: [],
      ...state,
    },
    sessions: [],
    memories: [],
  };
  if (legacy) {
    delete snapshot.state.conversation;
    delete snapshot.state.memory_proposals;
  }
  let failures = rejectEdits;
  let polls = 0;
  const api = {
    catalog: async () => [
      [
        { path: "/a", name: "Project A" },
        { path: "/b", name: "Project B" },
      ],
      [],
    ],
    snapshot: async () => {
      polls += 1;
      if (polls > 1 && onPoll) onPoll(snapshot.state, polls);
      return structuredClone(snapshot);
    },
    edit: async (revision, edit) => {
      calls.push({ revision, edit });
      if (beforeEdit) await beforeEdit(edit);
      if (failures > 0) {
        failures -= 1;
        throw new Error("Network lost");
      }
      if (edit.kind === "say")
        snapshot.state.conversation = [
          ...(snapshot.state.conversation ?? []),
          turn({ id: edit.turn_id, content: edit.content }),
        ];
      return snapshot.state;
    },
    memory: async () => {},
  };
  mounted.push(
    mount(
      <I18nProvider>
        <AssistantWorkspace
          activity={<p>Real execution view</p>}
          api={api}
          onSelect={(id) => calls.push({ open: id })}
          onClose={() => calls.push({ close: true })}
        />
      </I18nProvider>
    )
  );
  return { calls, snapshot };
}

const composer = () =>
  dom.document.querySelector(
    'textarea[aria-label="Message to chief of staff"]'
  );
const panel = () => dom.document.querySelector("section > div.overflow-y-auto");
const text = () => dom.document.body.textContent;
function type(value) {
  composer().value = value;
  Simulate.change(composer());
}
async function ready() {
  await waitFor(() => expect(composer()).not.toBeNull());
  await waitFor(() =>
    expect(button(dom.document.body, "Project scope (optional)")).toBeDefined()
  );
}
async function expandGoals() {
  await waitFor(() =>
    expect(button(dom.document.body, "1 in progress")).toBeDefined()
  );
  click(button(dom.document.body, "1 in progress"));
  await flush();
}
const sayCalls = (calls) => calls.filter((c) => c.edit?.kind === "say");

test("work items stay collapsed on the home view and the composer remains reachable", async () => {
  render({
    state: { goals: [goal(), goal({ id: "g2", title: "Release prep" })] },
  });
  await ready();
  expect(text()).not.toContain("Login fix");
  expect(text()).not.toContain("Request stop");
  expect(() => button(dom.document.body, "Project A")).toThrow();
  const toggle = button(dom.document.body, "2 in progress");
  expect(toggle.getAttribute("aria-expanded")).toBe("false");
  // The composer sits outside the scrolling stream, so history cannot push it away.
  expect(composer().closest(".overflow-y-auto")).toBeNull();
  click(toggle);
  await flush();
  expect(text()).toContain("Login fix");
  expect(text()).toContain("Release prep");
});

test("only goals referenced by the conversation are shown without expanding", async () => {
  render({
    state: {
      goals: [goal(), goal({ id: "g2", title: "Release prep" })],
      conversation: [turn({ goal_ids: ["g2"] })],
    },
  });
  await waitFor(() => expect(text()).toContain("Release prep"));
  expect(text()).not.toContain("Login fix");
  expect(button(dom.document.body, "1 in progress")).toBeDefined();
});

test("a plain question sends only a say and never creates a goal or request", async () => {
  const { calls } = render();
  await ready();
  type("  How is the login fix going?  ");
  await flush();
  click(button(dom.document.body, "Send"));
  await waitFor(() => expect(sayCalls(calls).length).toBe(1));
  const [{ edit, revision }] = sayCalls(calls);
  expect(edit.content).toBe("How is the login fix going?");
  expect(edit.turn_id).toMatch(/^[0-9a-f-]{36}$/u);
  expect("project_paths" in edit).toBe(false);
  expect(revision).toBe(5);
  expect(calls.some((c) => ["goal", "request"].includes(c.edit?.kind))).toBe(
    false
  );
  await waitFor(() => expect(composer().value).toBe(""));
  // The reply comes from Core; the UI never invents one.
  expect(text()).toContain("Recorded");
});

test("typing the next message while a send finishes preserves the new draft", async () => {
  let release;
  const pending = new Promise((resolve) => {
    release = resolve;
  });
  const { calls } = render({ beforeEdit: () => pending });
  await ready();
  type("First message");
  await flush();
  click(button(dom.document.body, "Send"));
  await waitFor(() => expect(sayCalls(calls).length).toBe(1));
  type("Next message");
  await flush();
  release();
  await waitFor(() => expect(text()).toContain("First message"));
  expect(composer().value).toBe("Next message");
});

test("one message may cover several projects without a required project choice", async () => {
  const { calls } = render();
  await ready();
  type("Watch A's login fix and B's release prep");
  await flush();
  expect(button(dom.document.body, "Send").disabled).toBe(false);
  click(button(dom.document.body, "Project scope (optional)"));
  await flush();
  click(button(dom.document.body, "Project B"));
  click(button(dom.document.body, "Project A"));
  await flush();
  click(button(dom.document.body, "Send"));
  await waitFor(() => expect(sayCalls(calls).length).toBe(1));
  expect(sayCalls(calls)[0].edit.project_paths).toEqual(["/a", "/b"]);
});

test("a failed send keeps the draft and retries with the same id until the text changes", async () => {
  const { calls } = render({ rejectEdits: 2 });
  await ready();
  type("Plan the release");
  await flush();
  click(button(dom.document.body, "Send"));
  await waitFor(() => expect(text()).toContain("Not sent"));
  expect(composer().value).toBe("Plan the release");
  click(button(dom.document.body, "Send"));
  await waitFor(() => expect(sayCalls(calls).length).toBe(2));
  await waitFor(() => expect(text()).toContain("Not sent"));
  const [first, second] = sayCalls(calls).map((c) => c.edit);
  expect(second).toEqual(first);
  type("Plan the release carefully");
  await flush();
  click(button(dom.document.body, "Send"));
  await waitFor(() => expect(sayCalls(calls).length).toBe(3));
  expect(sayCalls(calls)[2].edit.turn_id).not.toBe(first.turn_id);
  await waitFor(() => expect(composer().value).toBe(""));
});

test("legacy snapshots without conversation fields still render", async () => {
  render({ legacy: true });
  await ready();
  expect(button(dom.document.body, "1 in progress")).toBeDefined();
});

test("intake outcomes are shown per message and an unknown one cannot be resent", async () => {
  const { calls } = render({
    state: {
      conversation: [
        turn({
          id: "t1",
          status: "unknown",
          source_run_id: null,
          error: "No receipt",
        }),
        turn({
          id: "t2",
          author: "assistant",
          content: "**Still** testing",
          reply_to: "t1",
          status: "handled",
        }),
      ],
      scoped_runs: [
        {
          scope: "turn:t1",
          run: { id: "r1", session_id: "review-1" },
          state: "failed",
          summary: "",
          error: "No receipt",
        },
      ],
    },
  });
  await waitFor(() =>
    expect(text()).toContain("will not be resent automatically")
  );
  expect(text()).toContain("No receipt");
  expect(text().split("No receipt").length - 1).toBe(1);
  expect(dom.document.querySelector("strong").textContent).toBe("Still");
  expect(
    [...dom.document.querySelectorAll("button")].some((b) =>
      /resend|retry/iu.test(b.textContent)
    )
  ).toBe(false);
  click(button(dom.document.body, "Open handling session"));
  expect(calls).toContainEqual({ open: "review-1" });
});

test("questions, proposals and deliveries inline use the original records", async () => {
  const delivered = goal({
    assignments: [
      {
        ...goal().assignments[0],
        result: {
          id: "res1",
          contract_revision: 1,
          evidence: "Checks passed",
          artifacts: [{ path: "login.txt", sha256: "b".repeat(64) }],
          state: "submitted",
        },
      },
    ],
  });
  const { calls } = render({
    state: {
      goals: [delivered],
      conversation: [
        turn({ id: "t1", goal_ids: ["g1"], question_ids: ["q1"] }),
      ],
      questions: [question()],
      changes: [
        {
          id: "c1",
          goal_id: "g1",
          from_revision: 1,
          to_revision: 2,
          before_title: "Login fix",
          before_acceptance: "Users can sign in",
          title: "Login and logout",
          acceptance: "Both work",
          reason: "Same flow",
          state: "proposed",
          proposed: true,
          remember: false,
          memory_id: null,
        },
      ],
    },
  });
  await waitFor(() => expect(text()).toContain("Which locale?"));
  // The version-bound delivery says it targets an older requirement version.
  expect(text()).toContain("Submitted; awaiting your review · v1");
  expect(text()).toContain("older version");
  expect(text()).toContain("login.txt");
  click(dom.document.querySelector('input[value="Chinese"]'));
  await flush();
  click(button(dom.document.body, "Send answer"));
  await waitFor(() =>
    expect(
      calls.some(
        (c) => c.edit?.question_id === "q1" && c.edit.answer === "Chinese"
      )
    ).toBe(true)
  );
  click(button(dom.document.body, "Apply change"));
  await waitFor(() =>
    expect(calls.some((c) => c.edit?.change_id === "c1")).toBe(true)
  );
  click(button(dom.document.body, "Review deliverable"));
  await flush();
  expect(button(panel(), "Request rework")).toBeDefined();
});

test("a permission request opens its original session and offers no inline approval", async () => {
  const { calls } = render({
    state: {
      conversation: [turn({ question_ids: ["q1"] })],
      questions: [
        question({
          title: "Allow shell?",
          source_input: {
            kind: "permission",
            options: [["allow", "Allow"]],
            context: {},
          },
        }),
      ],
    },
  });
  await waitFor(() => expect(text()).toContain("Allow shell?"));
  expect(dom.document.querySelector('input[value="allow"]')).toBeNull();
  expect(
    [...dom.document.querySelectorAll("button")].some(
      (b) => b.textContent === "Send answer"
    )
  ).toBe(false);
  click(button(dom.document.body, "Open original session"));
  expect(calls).toContainEqual({ open: "s1" });
  expect(calls.some((c) => c.edit)).toBe(false);
});

test("memory suggestions show scope and text and bind the content hash", async () => {
  const { calls } = render({
    state: { conversation: [turn()], memory_proposals: [proposal()] },
  });
  await waitFor(() =>
    expect(text()).toContain("Release notes are written in Chinese")
  );
  expect(text()).toContain("Project A");
  expect(text()).toContain("#abcdef01");
  click(button(dom.document.body, "Remember"));
  await waitFor(() =>
    expect(calls.find((c) => c.edit?.kind === "confirm_memory")?.edit).toEqual({
      kind: "confirm_memory",
      proposal_id: "p1",
      content_hash: "abcdef0123456789",
    })
  );
});

test("a memory suggestion whose text changed before the click is not applied", async () => {
  const { calls } = render({
    state: { conversation: [turn()], memory_proposals: [proposal()] },
    onPoll: (state) => {
      state.memory_proposals[0].content_hash = "ffffffff00000000";
    },
  });
  await waitFor(() => expect(text()).toContain("Release notes are written"));
  click(button(dom.document.body, "Remember"));
  await waitFor(() => expect(text()).toContain("This target changed"));
  expect(calls.some((c) => c.edit)).toBe(false);
});

test.each([
  [null, "Confirmed; waiting to save"],
  ["memory-1", "Saved to memory"],
])("confirmed memory receipt %s shows %s", async (memory_id, label) => {
  render({
    state: {
      conversation: [turn()],
      memory_proposals: [proposal({ state: "confirmed", memory_id })],
    },
  });
  await waitFor(() => expect(text()).toContain(label));
  expect(text()).toContain("Release notes are written in Chinese");
  if (memory_id == null) expect(text()).not.toContain("Saved to memory");
});

test("sameEditTarget checks memory proposals and the question a say answers", () => {
  const before = {
    memory_proposals: [proposal()],
    questions: [question()],
    goals: [],
  };
  const confirm = {
    kind: "confirm_memory",
    proposal_id: "p1",
    content_hash: "abcdef0123456789",
  };
  expect(sameEditTarget(before, structuredClone(before), confirm)).toBe(true);
  const rehashed = structuredClone(before);
  rehashed.memory_proposals[0].content_hash = "other";
  expect(
    sameEditTarget(before, rehashed, { ...confirm, kind: "reject_memory" })
  ).toBe(false);
  const done = structuredClone(before);
  done.memory_proposals[0].state = "confirmed";
  expect(sameEditTarget(before, done, confirm)).toBe(false);
  const say = {
    kind: "say",
    turn_id: "x",
    content: "ok",
    answers_question: "q1",
  };
  expect(sameEditTarget(before, structuredClone(before), say)).toBe(true);
  const newer = structuredClone(before);
  newer.questions[0].contract_revision = 3;
  expect(sameEditTarget(before, newer, say)).toBe(false);
  expect(
    sameEditTarget(before, newer, { kind: "say", turn_id: "y", content: "hi" })
  ).toBe(true);
});

test("stop and take over are reachable from the conversation", async () => {
  const { calls } = render();
  await ready();
  await expandGoals();
  click(button(dom.document.body, "Request stop"));
  await waitFor(() =>
    expect(
      calls.some(
        (c) =>
          c.edit?.kind === "control" &&
          c.edit.operation === "stop" &&
          c.edit.goal_id === "g1"
      )
    ).toBe(true)
  );
  click(button(dom.document.body, "Take over"));
  await waitFor(() =>
    expect(
      calls.some((c) => c.edit?.kind === "takeover" && c.edit.id === "g1")
    ).toBe(true)
  );
});

test("latest progress stays visible while earlier updates remain available on demand", async () => {
  const note = (id, goal_id, title) => ({
    id,
    goal_id,
    title,
    body: title,
    session_id: null,
    read: false,
    kind: "progress",
  });
  render({
    state: {
      notifications: [
        note("n1", "g1", "Earlier A"),
        note("n2", "g2", "Latest B"),
        note("n3", "g1", "Latest A"),
      ],
    },
  });
  await waitFor(() => expect(text()).toContain("Latest A"));
  expect(text()).toContain("Latest B");
  expect(text()).not.toContain("Earlier A");
  click(button(dom.document.body, "Earlier updates (1)"));
  await waitFor(() => expect(text()).toContain("Earlier A"));
});

test("polling and opening details keep the unsent draft", async () => {
  render({
    onPoll: (state) => {
      state.revision += 1;
      state.turns += 1;
    },
  });
  await ready();
  await expandGoals();
  type("Half written plan");
  await flush();
  click(button(dom.document.body, "Details"));
  await flush();
  expect(panel().hidden).toBe(false);
  await new Promise((resolve) => setTimeout(resolve, 5300));
  click(button(dom.document.body, "Back to conversation"));
  await flush();
  expect(composer().value).toBe("Half written plan");
}, 15000);
