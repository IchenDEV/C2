import React, {useState,useRef} from 'react';
import { createRoot } from 'react-dom/client';
import { AssistantWorkspace } from '@/assistant/AssistantWorkspace';
import { I18nProvider } from '@/i18n';
import { ThemeProvider } from '@/theme';
import { TooltipProvider } from '@/components/ui/tooltip';
import { ToastProvider } from '@/ui/toast';
import { Composer } from '@/session/Composer';
import { TranscriptPane } from '@/session/TranscriptPane';
import { DocEditor } from '@/editor/Editor';
import { newTurn } from '@/session/turns';
import fixture from './fixture-state.json';
import '@/styles.css';

// Offline UI fixture only: no Engine connection, Provider or external message.
const state = structuredClone(fixture);
const calls: unknown[] = [];
const memories = [{ id:'fixture-memory', project_path:'codetwo://chief-of-staff', category:'preference', content:'先告诉我需要决定什么。', active:true, layer:'L1', source_type:'user', source_id:'fixture-ui', provenance:{kind:'user'}, created_at:Date.now(), updated_at:Date.now() }];
const api = {
  snapshot:async()=>({state:structuredClone(state),sessions:[],memories:structuredClone(memories)}),
  catalog:async()=>[[{path:'/fixture/project-a',name:'项目 A'},{path:'/fixture/project-b',name:'项目 B'}], [{id:'grok',display_name:'Offline fixture',available:true,enabled:true,models:[]}]],
  edit:async(revision:number, action:any)=>{
    calls.push({revision,action});
    if (action.kind === 'say') state.conversation.push({id:action.turn_id,created_at:new Date().toISOString(),author:'user',content:action.content,reply_to:null,project_paths:action.project_paths??[],status:'recorded',goal_ids:[],question_ids:[],error:null,source_run_id:null});
    if (action.kind === 'control') state.goals.find(g=>g.id===action.goal_id)!.assignments.at(-1)!.stop_requested=true;
    if (action.kind === 'takeover') state.goals.find(g=>g.id===action.id)!.assignments.at(-1)!.taken_over=true;
    if (action.kind === 'confirm_memory' || action.kind === 'reject_memory') {const p=state.memory_proposals.find(p=>p.id===action.proposal_id)!;p.state=action.kind==='confirm_memory'?'confirmed':'rejected';p.memory_id=action.kind==='confirm_memory'?'fixture-saved-memory':null;}
    state.revision++;
  },
  memory:async(name:string,args:any)=>{calls.push({name,args});return null;}
};
Object.assign(window,{__fixture:{state,calls}});
function fixtureConfig(overrides = {}) {
  return {
    providers: [],
    providersStatus: "ready",
    provider: "codex",
    onProvider: () => calls.push({mainControl:true}),
    onProviderModel: () => calls.push({mainControl:true}),
    onReloadProviders: () => calls.push({mainControl:true}),
    mode: "ask",
    sandbox: "workspace_write",
    modeChangeDisabled: false,
    onSessionMode: () => calls.push({mainControl:true}),
    worktreeBase: null,
    activeWorktreeBaseline: null,
    activeWorktreeUnknown: false,
    worktreeOptions: [
      {
        kind: "current",
        resolved: {
          kind: "current",
          ref: "refs/heads/main",
          sha: "3befbb7dbec99119065c78a818c2b04f6c90ea0d",
          display: "main @ 3befbb7d",
        },
        unavailable_reason: null,
      },
      {
        kind: "origin_default",
        resolved: {
          kind: "origin_default",
          ref: "refs/remotes/origin/main",
          sha: "3befbb7dbec99119065c78a818c2b04f6c90ea0d",
          display: "origin/main @ 3befbb7d",
        },
        unavailable_reason: null,
      },
    ],
    worktreeOptionsLoading: false,
    onWorktreeBase: () => calls.push({mainControl:true}),

    memoryEnabled: true,
    memoryRead: "inherit",
    memoryWrite: "inherit",
    onMemoryPolicy: () => calls.push({mainControl:true}),
    hasSession: false,
    scenesEnabled: false,
    scenes: [],
    activeScene: null,
    autoScene: false,
    onAutoScene: () => calls.push({mainControl:true}),
    onScene: () => calls.push({mainControl:true}),
    onManageScenes: () => calls.push({mainControl:true}),
    sceneCustomized: false,
    scenePendingFields: [],
    onRestartInScene: () => calls.push({mainControl:true}),
    ...overrides,
  };
}

// Actual main Composer + DocEditor defaults in the same offline browser; actions are recorded only.
function MainFixture(){
 const [docMode,setDocMode]=useState(false),[empty,setEmpty]=useState(true);
 const bounds=useRef(null),blocks=useRef(null),focus=useRef(null),clear=useRef(null);
 const [turn]=useState(()=>Object.assign(newTurn('检查主对话输入框与消息组件。'),{accepted:true,streamBoundaryKnown:true,text:'主会话仍保留原有执行状态、配置与输入逻辑。',content:[{kind:'text',text:'主会话仍保留原有执行状态、配置与输入逻辑。',transcriptSeq:1}],endedAt:Date.now()}));
 const action=()=>calls.push({mainAction:true,doc:blocks.current?.()});
 return <section ref={bounds} style={{height:'100vh',display:'flex',flexDirection:'column'}}>
 {!docMode&&<TranscriptPane variant="main" sessionId="offline-main-render" turns={[turn]}/>}
 <Composer config={fixtureConfig()} models={[]} currentModel={null} defaultModel={null} contextWindow={null}
 onModel={action} configOptions={[]} onConfigOption={action}
 checkout={{project:'离线主会话',branch:'render-fixture',dirty:0,onOpen:action}}
 docMode={docMode} onDocMode={setDocMode} boundsRef={bounds}
 running={false} loading={false} docEmpty={empty} onRun={action} onQueue={action} onMultitask={action} onSteer={action} onStop={action}
 steeringSupported={false} onAttachFile={action} onAttachImages={action} onInsertSkill={action} onInsertIssue={action} onOpenMarket={action} onNewSkill={action}
 canvasEnabled={false} onInsertCanvas={action} voiceEnabled={false} onVoiceText={action} runHint="⌘Enter" skillHint="" filesHint="">
 <DocEditor sessionId={null} getBlocksRef={blocks} focusRef={focus} clearRef={clear} onEmptyChange={setEmpty}/>
 </Composer></section>
}

const main = new URLSearchParams(location.search).has('main');
createRoot(document.getElementById('root')!).render(<I18nProvider preferenceOverride="zh-CN"><ThemeProvider preferenceOverride="system"><TooltipProvider><ToastProvider>{main?<MainFixture/>:<AssistantWorkspace activity={<p>离线执行诊断夹具</p>} onSelect={id=>calls.push({select:id})} onClose={()=>calls.push({close:true})} api={api as any}/>}</ToastProvider></TooltipProvider></ThemeProvider></I18nProvider>);
