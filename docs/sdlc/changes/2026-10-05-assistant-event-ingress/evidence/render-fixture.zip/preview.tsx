import React, {useState,useRef} from 'react';
import { createRoot } from 'react-dom/client';
import { AssistantWorkspace } from '@/assistant/AssistantWorkspace';
import { I18nProvider } from '@/i18n';
import { ThemeProvider } from '@/theme';
import { TooltipProvider } from '@/components/ui/tooltip';
import { ToastProvider } from '@/ui/toast';
import fixture from './fixture-state.json';
import '@/styles.css';

// Offline UI fixture only: no Engine connection, Provider or external message.
const state = structuredClone(fixture);
const calls: unknown[] = [];
const memories = [{ id:'fixture-memory', project_path:'codetwo://chief-of-staff', category:'preference', content:'先告诉我需要决定什么。', active:true, layer:'L1', source_type:'user', source_id:'fixture-ui', provenance:{kind:'user'}, created_at:Date.now(), updated_at:Date.now() }];
const source = {source_id:'fixture-source',principal:{plugin:'bundle:offline-fixture',realm:'global',connector_id:'events'},provider:'fixture',account_scope:'offline-test-account',resource_filter:['fixture-room'],actor_filter:[],project_paths:['/fixture/project-a'],goal_ids:[state.goals[0].id],streams:['main'],version:1,enabled:true,history_limit:null};
state.sources=[source];
const observations={health:[{key:source.source_id,kind:'source',state:'needs_reset',accepted:5,filtered:2,duplicate:1,conflicts:0,rejected:1,unbound:0,gap_count:1,gap_first:'old',gap_last:'new',detail:'离线夹具：提供方历史游标过期，请明确缺口。'}],receipts:['handled','unknown','deferred_paused','reviewing'].map((status,i)=>({observation_id:'fixture-observation-'+i,goal_id:state.goals[0].id,source_id:source.source_id,binding_version:1,project_path:'/fixture/project-a',state:status,run_id:i===3?'fixture-review':null,output_id:i===0?'fixture-output':null,seq:i})),connectors:[{...source.principal,provider:'fixture',label:'模拟来源 · 离线验收'}],streams:[{source_id:source.source_id,stream_id:'main',checkpoint:'old-cursor'}],resets:[]};
const api = {
  observations:async()=>structuredClone(observations),
  snapshot:async()=>({state:structuredClone(state),sessions:[],memories:structuredClone(memories)}),
  catalog:async()=>[[{path:'/fixture/project-a',name:'项目 A'},{path:'/fixture/project-b',name:'项目 B'}], [{id:'grok',display_name:'Offline fixture',available:true,enabled:true,models:[]}]],
  edit:async(revision:number, action:any)=>{
    calls.push({revision,action});
    if (action.kind === 'say') state.conversation.push({id:action.turn_id,created_at:new Date().toISOString(),author:'user',content:action.content,reply_to:null,project_paths:action.project_paths??[],status:'recorded',goal_ids:[],question_ids:[],error:null,source_run_id:null});
    if (action.kind === 'control') state.goals.find(g=>g.id===action.goal_id)!.assignments.at(-1)!.stop_requested=true;
    if (action.kind === 'takeover') state.goals.find(g=>g.id===action.id)!.assignments.at(-1)!.taken_over=true;
    if (action.kind === 'confirm_memory' || action.kind === 'reject_memory') {const p=state.memory_proposals.find(p=>p.id===action.proposal_id)!;p.state=action.kind==='confirm_memory'?'confirmed':'rejected';p.memory_id=action.kind==='confirm_memory'?'fixture-saved-memory':null;}
    if(action.kind==='source_reset') observations.resets.push({approval_ref:'fixture-approved-reference',source_id:source.source_id,binding_version:1,stream_id:action.stream_id,checkpoint_before:action.checkpoint_before,checkpoint_after:action.checkpoint_after,reason:action.reason,approved_at_ms:Date.now()});
    state.revision++;
  },
  memory:async(name:string,args:any)=>{calls.push({name,args});return null;}
};
Object.assign(window,{__fixture:{state,calls,observations}});
createRoot(document.getElementById('root')!).render(<I18nProvider preferenceOverride="zh-CN"><ThemeProvider preferenceOverride="system"><TooltipProvider><ToastProvider><AssistantWorkspace activity={<p>离线执行诊断夹具</p>} onSelect={id=>calls.push({select:id})} onClose={()=>calls.push({close:true})} api={api as any}/></ToastProvider></TooltipProvider></ThemeProvider></I18nProvider>);
