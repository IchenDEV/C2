import path from 'node:path';
const root=process.cwd();
const {build}=await import(path.join(root,'apps/desktop/node_modules/vite/dist/node/index.js'));
await build({root:path.join(root,'apps/desktop'),configFile:path.join(root,'apps/desktop/vite.config.ts'),mode:'web',resolve:{alias:{'react-compiler-runtime':path.join(root,'apps/desktop/node_modules/react-compiler-runtime')}},cacheDir:path.join(root,'.codex/run/assistant-event-memory/render/vite-cache'),build:{outDir:path.join(root,'.codex/run/assistant-event-memory/render/offline-build'),emptyOutDir:true,rollupOptions:{input:path.join(root,'.codex/run/assistant-event-memory/render/preview.tsx'),output:{inlineDynamicImports:true}}}});
