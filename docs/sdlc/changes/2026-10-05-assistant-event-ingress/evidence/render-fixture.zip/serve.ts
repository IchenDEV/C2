import path from 'node:path';
const root=process.cwd();
const {createServer}=await import(path.join(root,'apps/desktop/node_modules/vite/dist/node/index.js'));
const server=await createServer({root:path.join(root,'apps/desktop'),configFile:path.join(root,'apps/desktop/vite.config.ts'),mode:'web',cacheDir:path.join(root,'.codex/run/assistant-event-memory/render/vite-cache'),server:{host:'127.0.0.1',port:14677,strictPort:true,fs:{allow:[root]}}});
await server.listen();server.printUrls();
process.on('SIGINT',async()=>{await server.close();process.exit(0)});
